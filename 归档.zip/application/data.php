<?php
/**
 * 用户自定义函数
 */
use think\Db;
    
